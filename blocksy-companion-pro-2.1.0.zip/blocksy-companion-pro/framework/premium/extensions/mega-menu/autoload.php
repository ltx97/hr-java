<?php

$autoload = [
	'Api' => 'includes/api.php',
	'CustomContent' => 'includes/custom-content.php',
	'ImportExport' => 'includes/import-export.php',
];

