<?php

$config = blc_exts_get_preliminary_config('adobe-typekit');

